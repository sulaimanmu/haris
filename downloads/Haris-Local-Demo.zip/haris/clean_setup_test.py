"""Copy only source into a fresh directory and launch with site packages disabled."""
import json
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path
from shutil import copy2,copytree

root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory() as tmp:
    destination=Path(tmp)
    for name in ('run.py','server.py','core.py'):copy2(root/name,destination/name)
    copytree(root/'static',destination/'static')
    with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
    process=subprocess.Popen([sys.executable,'-S',str(destination/'run.py'),'--port',str(port)],cwd=destination,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        for _ in range(50):
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.5) as r:health=json.load(r)
                break
            except Exception:time.sleep(.1)
        else:raise RuntimeError('fresh source setup failed to start')
        credentials=json.loads((destination/'.runtime/demo-credentials.json').read_text())
        req=urllib.request.Request(f'http://127.0.0.1:{port}/api/login',json.dumps({'username':'amal','password':credentials['amal']}).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(req) as r:cookie=r.headers['Set-Cookie'].split(';')[0];user=json.load(r)['user']
        payload={'customer_id':'C101','prompt':'Summarize the annual review.','model':'local-template','tool':'draft_case','language':'en'}
        req=urllib.request.Request(f'http://127.0.0.1:{port}/api/gateway',json.dumps(payload).encode(),{'Content-Type':'application/json','Cookie':cookie,'X-CSRF-Token':user['csrf']})
        with urllib.request.urlopen(req) as r:result=json.load(r)
        assert result['status']=='allowed' and result['output'] and result['audit_hash']
        report={'pass':True,'python':sys.version,'command':'python -S run.py --port <ephemeral>','dependencies':'standard library only; site packages disabled','checks':['fresh source-only copy','automatic database/key/password creation','health','authentication','CSRF-authenticated request','non-empty model-adapter result and audit hash'],'at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
        (root/'evidence/clean-setup.json').write_text(json.dumps(report,indent=2))
        print(json.dumps(report,indent=2))
    finally:
        process.terminate();process.wait(timeout=10)
