"""Public hash-chain check. A separately retained head detects removed tail events.
HMAC authenticity is checked only by the running gateway, whose key is not exported.
"""
import argparse
import json
from pathlib import Path
from core import digest

def verify(bundle, trusted_head):
    previous='0'*64
    if bundle['count']!=len(bundle['events']):return False
    for i,raw in enumerate(bundle['events'],1):
        event={k:v for k,v in raw.items() if k not in ('hash','mac')}
        if event['seq']!=i or event['tenant']!=bundle['tenant'] or event['previous']!=previous or digest(event)!=raw['hash']:return False
        previous=raw['hash']
    return previous==bundle['head']==trusted_head

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('file');p.add_argument('--trusted-head',required=True);a=p.parse_args()
    valid=verify(json.loads(Path(a.file).read_text(encoding='utf-8')),a.trusted_head)
    print('PASS: chain matches independently retained head' if valid else 'FAIL: chain/head mismatch')
    raise SystemExit(0 if valid else 1)
