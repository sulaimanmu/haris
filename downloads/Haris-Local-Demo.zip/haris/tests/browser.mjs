import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';
const root=path.resolve('.');
const credentials=JSON.parse(await fs.readFile(path.join(root,'.runtime/demo-credentials.json'),'utf8'));
const out=path.join(root,'evidence/screenshots');await fs.mkdir(out,{recursive:true});
const browser=await chromium.launch({headless:true,channel:'msedge'});
const page=await browser.newPage({viewport:{width:1440,height:1050},deviceScaleFactor:1});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
async function login(name){await page.goto('http://127.0.0.1:8765');await page.locator('#username').selectOption(name);await page.locator('#password').fill(credentials[name]);await page.locator('#login-form button').click();await page.locator('#request-form').waitFor();}
async function shot(name){await page.screenshot({path:path.join(out,name+'.png'),fullPage:true});const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);if(overflow)throw new Error('horizontal overflow '+name);}
await login('amal');await page.locator('#run').click();await page.locator('.result-status.allowed').waitFor();
if(!(await page.locator('#result').textContent()).includes('[CIVIL_ID]'))throw new Error('redaction absent');
await shot('desktop-en-safe');
await page.locator('[data-scenario="injection"]').click();await page.locator('#run').click();await page.locator('.result-status.blocked').waitFor();await shot('desktop-en-blocked');
await page.locator('[data-scenario="approval"]').click();await page.locator('#run').click();await page.locator('.result-status.approval_required').waitFor();
await page.locator('#logout').click();await login('noura');await page.locator('[data-page="approvals"]').click();await page.locator('[data-approve]').first().waitFor();await shot('desktop-en-approval');const previousCaseCount=await page.locator('#cases .approval-card').count();await page.locator('[data-approve]').first().click();await page.waitForFunction(count=>document.querySelectorAll('#cases .approval-card').length===count+1,previousCaseCount);
await page.locator('[data-page="audit"]').click();await page.locator('table tbody tr').first().waitFor();await shot('desktop-en-audit');
await page.locator('#language').click();await page.locator('table tbody tr').first().waitFor();await shot('desktop-ar-audit');
await page.locator('#logout').click();await login('amal');await page.locator('#run').click();await page.locator('.result-status.allowed').waitFor();await shot('desktop-ar-safe');
await page.setViewportSize({width:390,height:844});await shot('mobile-ar-safe');
await page.locator('[data-scenario="injection"]').click();await page.locator('#run').click();await page.locator('.result-status.blocked').waitFor();await shot('mobile-ar-blocked');
await page.locator('#language').click();await shot('mobile-en-blocked');
await page.locator('[data-page="policy"]').click();await shot('mobile-en-policy');
await page.setViewportSize({width:1440,height:1050});await page.locator('[data-page="workspace"]').click();await page.locator('[data-scenario="safe"]').click();await page.locator('#model').selectOption('qwen2.5:0.5b');await page.locator('#run').click();await page.locator('.result-status.allowed').waitFor({timeout:100000});await shot('desktop-en-live-model');
const liveText=await page.locator('#result').innerText();
await fs.writeFile(path.join(root,'evidence/browser-qa.json'),JSON.stringify({at:new Date().toISOString(),browser:'Chromium via installed Edge, headless',viewports:['1440x1050','390x844'],screenshots:11,checks:['authenticated sign-in','safe redaction','blocked injection','independent approval produces filed case','audit view','English and Arabic RTL','no horizontal overflow at both viewports','real local Qwen inference'],pageErrors:errors,liveResult:liveText},null,2));
if(errors.length)throw new Error(errors.join('\n'));
await browser.close();console.log('Browser E2E completed; screenshots and report saved.');
