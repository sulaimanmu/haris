"""Run the same fixed corpus against the fixed local Ollama route."""
import argparse
import json
import platform
import tempfile
import time
import urllib.request
from pathlib import Path
from core import Gateway, USERS, CUSTOMERS, digest
from tests.corpus import CASES
from evaluate import p95

def main(out):
    with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=5) as response:tags=json.load(response)
    model=next(m for m in tags['models'] if m['name']=='qwen2.5:0.5b')
    rows=[]
    with tempfile.TemporaryDirectory() as temp:
        g=Gateway(temp);user={"id":"amal",**USERS['amal']}
        for case in CASES:
            request={**case['request']}
            if request['model']=='local-template':request['model']='qwen2.5:0.5b'
            result=g.process(user,request)
            rows.append({**case,'request':request,'result':result})
        evidence=g.evidence(user);g.db.close()
    benign=[r for r in rows if r['label']=='benign'];attacks=[r for r in rows if r['label']=='attack']
    forbidden=[v for id in ('C102','C201') for k,v in CUSTOMERS[id].items() if k in ('name','civil','email','phone','iban')]
    leaks=[r['id'] for r in rows if any(v in (r['result']['output']+r['result']['minimized_input']) for v in forbidden)]
    summary={'measured_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'model':model,'platform':platform.platform(),'cases':len(rows),'source_corpus_sha256':digest(CASES),'attacks':len(attacks),'blocked':sum(r['result']['status']=='blocked' for r in attacks),'benign':len(benign),'false_positives':sum(r['result']['status']!='allowed' for r in benign),'literal_cross_customer_leaks':leaks,'audit_complete':sum(e['action']=='gateway' for e in evidence['events']),'audit_integrity':evidence['integrity'],'p95_added_ms':p95([r['result']['added_ms'] for r in rows]),'p95_model_ms':p95([r['result']['model_ms'] for r in rows if r['result']['model_ms']>0]),'inference_errors':[r['id'] for r in rows if r['result']['reason']=='unavailable'],'missed_attacks':[r['id'] for r in attacks if r['result']['status']!='blocked'],'measurement':'One sequential pass, fixed local Qwen, temperature 0 and seed 42. Model time reported separately. Literal fixture leakage only; human review of factual/Arabic quality remains necessary.'}
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    (out/'metrics.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    (out/'cases-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',default='evidence/live-run');a=p.parse_args();main(a.out)
