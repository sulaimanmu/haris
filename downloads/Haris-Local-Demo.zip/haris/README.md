# Haris / حارس

A working local AI security gateway for one synthetic banking workflow: prepare a customer-review draft and independently approve its internal filing.

**Prototype, not a production banking system.** No CBK approval, funding, licence, sandbox entry or adoption is implied. No real bank/customer data or external financial actions are used.

## One-command setup

Requires Python 3.11 or later. From this folder:

```console
python run.py --credentials
```

Open **http://127.0.0.1:8765**. Startup creates the database, independent random account passwords and the audit key. The command prints the generated local demo passwords. No Python packages, paid API, Docker or internet connection is required. The generated credentials also live in `.runtime/demo-credentials.json`; keep that file and the audit key private. Ctrl+C stops the server. Do not expose the loopback service to a network.

| Account | Tenant | Role / scope |
|---|---|---|
| amal | atlas | Relationship manager, customer C101 |
| noura | atlas | Independent reviewer, C101 and C102 |
| ali | atlas | Relationship manager, C102 |
| bader | bayt | Relationship manager, C201 |
| sara | bayt | Independent reviewer, C201 |

## Five-minute demonstration

1. **0:00–0:45, safe request:** sign in as Amal. Run “Safe + redaction”. Inspect the redacted name, Civil ID and email, draft and evidence hash. The default **deterministic test adapter** is explicitly a regression fixture, not an AI model.
2. **0:45–1:30, real AI:** select **Local Qwen 2.5 · 0.5B** if the local model is installed. Run the same request; the gateway forwards minimized text and receives a real model draft. Explain that small-model quality is limited and the model has no execution authority.
3. **1:30–2:30, attacks:** run “Prompt injection”, “Cross-customer” and “Exfiltration”. Inspect the server decision and absence of model release. Try an unapproved model or external-send tool. A custom request can be edited freely within the request size limit.
4. **2:30–3:45, human control:** run “Approval required”. Open Human review as Amal: no approve button is available. Sign out, sign in as Noura, open Human review and inspect the full draft/content digest. Approve the new pending request. A real internal case is now stored. Rejected requests produce no case, and an approved request cannot execute twice.
5. **3:45–5:00, evidence and Arabic:** open Audit evidence as Noura, inspect chain integrity and bilingual reasons, then export JSON. Switch to العربية and inspect RTL layout. Save the final evidence head separately to detect later truncation. State the measured misses/false positive and production gaps.

Policy 1.1 restricts queue reads and decisions to currently assigned customers, including after reviewer access changes. Pending approvals expire after 15 minutes. If an old demo item expires, create a fresh request. Sessions expire after 30 minutes; signing in again revokes the preceding session for that account. The UI offers predefined safe/blocked/approval-required inputs on every fresh setup, so no earlier database is needed for the demonstration.

## Real local model

For the complete real-model demo, install [Ollama](https://docs.ollama.com/) as a prerequisite alongside Python, then use one setup command:

```console
python run.py --prepare-model --credentials
```

This starts the installed local model service if necessary, downloads the fixed model once if absent, and launches Haris. It does not require a paid account. If you already manage Ollama yourself, the equivalent model preparation is:

```console
ollama pull qwen2.5:0.5b
```

Select the local Qwen route in Haris. It calls only `http://127.0.0.1:11434/api/chat`, never a user-supplied destination. The downloaded model is about 398 MB. Subsequent inference is local. The tested model digest and outputs are in `evidence/live-final/`. See [official model details and licence](https://ollama.com/library/qwen2.5:0.5b). Missing/failed inference blocks the request and creates no approval; it never silently substitutes the deterministic adapter.

## Demonstration computer

Measured on a Dell XPS 9320, Intel Core i7-1280P, approximately 32 GB RAM and integrated Iris Xe graphics. Ollama confirmed 100% CPU inference. The small local Qwen model produced a correct English review summary without a discrete GPU or paid API. This is a working small-model example on a general-purpose laptop, not proof of consistently correct generation: an Arabic draft invented a date, and the revised prompt still sometimes echoes source text. See the preserved failure, hardware inventory and quality checks in `docs/evaluation.md`.

## Verification and actual results

```console
python -m unittest discover -s tests -v
python evaluate.py --out evidence/reproduced
python audit_results.py
python clean_setup_test.py
python live_evaluate.py --out evidence/live-reproduced
```

The last command requires the real model. Other Python checks use only the standard library. Clean setup copies source to a new temporary directory, disables Python site packages, launches the app and completes authenticated API processing.

The fixed corpus contains **48 cases: 20 benign, 22 adversarial, 6 requiring approval**. Two sequential five-repeat runs each processed 240 requests. Both blocked **20/22 attacks (90.9%)**, produced **1/20 benign false positives (5%)**, required approval for **6/6** filing cases, found **0 literal forbidden customer-fixture disclosures**, and recorded **240/240** gateway decision events. Added gateway p95 was **13.193 ms** and **13.321 ms** on the recorded machine/configuration. These are measured prototype results, not bank traffic, a load test or universal security claims.

The 48-case local Qwen pass is reported separately; raw outputs are retained. The detector misses a paraphrased instruction and an encoded instruction, and blocks a benign training quotation. Security depends on server-controlled data/action boundaries as well as detection. Detailed methods, limitations and live-model results: `docs/evaluation.md`.

Browser E2E checks use Playwright as an optional development dependency. App runtime does not need it. Install the pinned dev package with `npm install`, ensure Edge is installed or configure the script's browser channel, start Haris, then run `npm run test:browser`. The test reads generated local credentials without printing them and saves screenshots. No manual browser-profile access is required.

## Evidence verification

Export a tenant evidence file as a reviewer, copy its final `head` into an independently protected record, and run:

```console
python verify_evidence.py evidence.json --trusted-head THE_SEPARATELY_RETAINED_HEAD
```

The command argument is your retained hash, not a secret. The public verifier checks the hash chain against it; the running gateway additionally checks HMACs using its private runtime key. Local evidence cannot withstand an administrator controlling both key and database. Production needs separate key custody, protected storage, identity integration, TLS, operations and independent assessment.

## Technical package

This public archive contains the working app, tests, source/control references, architecture, evaluation and synthetic evidence. The complete application and CV background are readable at https://sulaimanmu.github.io/haris/application.html and are separate from this technical archive. Generated runtime credentials, keys and databases are excluded.
