"""Reproducible fixed-case evaluation, with all outcomes retained."""
import argparse
import json
import math
import platform
import tempfile
import time
from pathlib import Path
from core import Gateway, USERS, CUSTOMERS, digest
from tests.corpus import CASES

def p95(values):return sorted(values)[math.ceil(.95*len(values))-1]

def main(out, repeat=5):
    with tempfile.TemporaryDirectory() as temp:
        g=Gateway(temp);user={"id":"amal",**USERS["amal"]}
        rows=[];latencies=[]
        for iteration in range(repeat):
            for case in CASES:
                result=g.process(user,case["request"])
                rows.append({"iteration":iteration,**case,"result":result})
                latencies.append(result["added_ms"])
        first=rows[:len(CASES)]
        attacks=[r for r in first if r["label"]=="attack"]
        benign=[r for r in first if r["label"]=="benign"]
        approvals=[r for r in first if r["label"]=="approval"]
        blocked=sum(r["result"]["status"]=="blocked" for r in attacks)
        fp=sum(r["result"]["status"]!="allowed" for r in benign)
        # Leakage is literal forbidden fixture data in returned model/minimized text.
        # Does not claim semantic privacy, arbitrary names or unseen-data coverage.
        forbidden=[v for id in ("C102","C201") for k,v in CUSTOMERS[id].items() if k in ("name","civil","email","phone","iban")]
        leaked=[r["id"] for r in rows if any(v in (r["result"]["output"]+r["result"]["minimized_input"]) for v in forbidden)]
        evidence=g.evidence(user)
        decision_events=[e for e in evidence["events"] if e["action"]=="gateway"]
        expected={r["result"]["id"] for r in rows}
        observed={e["request_id"] for e in decision_events}
        complete=len(expected&observed)
        summary={"corpus_version":"1.0","corpus_sha256":digest(CASES),"fixed_cases":len(CASES),"repeats":repeat,"measured_requests":len(rows),"attacks":len(attacks),"attacks_blocked":blocked,"block_rate":blocked/len(attacks),"benign":len(benign),"false_positives":fp,"false_positive_rate":fp/len(benign),"approval_cases":len(approvals),"approval_required":sum(r["result"]["status"]=="approval_required" for r in approvals),"cross_customer_literal_leaks":len(leaked),"leaked_case_ids":leaked,"audit_complete":complete,"audit_expected":len(rows),"audit_completeness":complete/len(rows),"audit_integrity":evidence["integrity"],"p95_added_ms":p95(latencies),"p50_added_ms":sorted(latencies)[len(latencies)//2],"missed_attacks":[r["id"] for r in attacks if r["result"]["status"]!="blocked"],"false_positive_cases":[r["id"] for r in benign if r["result"]["status"]!="allowed"],"measured_at_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"python":platform.python_version(),"platform":platform.platform(),"processor":platform.processor(),"measurement":"Sequential Gateway.process wall time minus model-call time, includes policy, redaction, SQLite commit and audit verification, excludes HTTP/authentication. Nearest-rank p95. Deterministic test adapter, no cloud. Warm Python process, fresh database growing across repeats."}
        out=Path(out);out.mkdir(parents=True,exist_ok=True)
        (out/"metrics.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
        (out/"cases-results.json").write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding="utf-8")
        (out/"audit-export.json").write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding="utf-8")
        print(json.dumps(summary,indent=2))
        g.db.close()

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--out",default="evidence/run-1");p.add_argument("--repeat",type=int,default=5);a=p.parse_args()
    if a.repeat<1:p.error("repeat must be positive")
    main(a.out,a.repeat)
