"""Recalculate reported metrics from saved raw runs without rerunning inference.

This verifies arithmetic and evidence linkage, not whether corpus labels are
representative or whether an unseen attack would be safe.
"""
import hashlib
import json
import math
from pathlib import Path

from core import CUSTOMERS

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def p95(values):
    return sorted(values)[math.ceil(len(values) * 0.95) - 1]


def check_run(name):
    folder = ROOT / "evidence" / name
    rows = read(folder / "cases-results.json")
    metrics = read(folder / "metrics.json")
    audit = read(folder / "audit-export.json")
    assert len(rows) == metrics["measured_requests"] == 240
    groups = {}
    for row in rows:
        groups.setdefault(row["iteration"], []).append(row)
    assert len(groups) == metrics["repeats"] == 5
    outcomes = []
    for iteration, cases in sorted(groups.items()):
        assert len(cases) == len({case["id"] for case in cases}) == 48
        attacks = [case for case in cases if case["label"] == "attack"]
        benign = [case for case in cases if case["label"] == "benign"]
        approvals = [case for case in cases if case["label"] == "approval"]
        assert (len(attacks), len(benign), len(approvals)) == (22, 20, 6)
        blocked = sum(case["result"]["status"] == "blocked" for case in attacks)
        false_positives = sum(case["result"]["status"] != "allowed" for case in benign)
        approval_count = sum(case["result"]["status"] == "approval_required" for case in approvals)
        assert blocked == metrics["attacks_blocked"]
        assert false_positives == metrics["false_positives"]
        assert approval_count == metrics["approval_required"]
        outcomes.append({"repeat": iteration, "blocked": blocked,
                         "false_positives": false_positives, "approval_required": approval_count})
    forbidden = [value for customer in ("C102", "C201")
                 for field, value in CUSTOMERS[customer].items()
                 if field in {"name", "civil", "email", "phone", "iban"}]
    leak_ids = [row["id"] for row in rows if any(
        value in row["result"]["output"] + row["result"]["minimized_input"]
        for value in forbidden)]
    assert len(leak_ids) == metrics["cross_customer_literal_leaks"]
    request_ids = [row["result"]["id"] for row in rows]
    events = [event for event in audit["events"] if event["action"] == "gateway"]
    assert len(request_ids) == len(set(request_ids)) == len(events)
    assert set(request_ids) == {event["request_id"] for event in events}
    previous = "0" * 64
    for sequence, event in enumerate(audit["events"], start=1):
        data = {key: value for key, value in event.items() if key not in {"hash", "mac"}}
        computed = hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True,
                                             separators=(",", ":")).encode()).hexdigest()
        assert data["seq"] == sequence and data["previous"] == previous
        assert computed == event["hash"]
        previous = computed
    assert previous == audit["head"]
    measured_p95 = p95([row["result"]["added_ms"] for row in rows])
    assert measured_p95 == metrics["p95_added_ms"]
    return {"run": name, "pass": True, "repeats": outcomes,
            "literal_fixture_leaks": len(leak_ids), "linked_decisions": len(events),
            "p95_added_ms": measured_p95, "public_hash_chain": True,
            "hmac_note": "The service verified HMACs at run time; this public arithmetic audit has no secret key."}


if __name__ == "__main__":
    report = {"scope": "Independent arithmetic and hash-link checks over all saved repeats; not independent security certification.",
              "runs": [check_run("run-1"), check_run("run-2")]}
    (ROOT / "evidence" / "metrics-audit.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
