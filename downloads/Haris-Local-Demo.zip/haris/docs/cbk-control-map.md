# CORF control-to-evidence map

Source: [CBK CORF v1.0, 3 December 2025](https://www.cbk.gov.kw/en/images/corf-170113_v10_tcm10-170113.pdf). PDF page numbers below match printed page numbers. Mapping is engineering interpretation, not legal advice, a certification or a claim of complete compliance. The entity remains responsible for applicability and governance.

| CORF reference | Relevant expectation, paraphrased | Prototype evidence | Remaining bank implementation |
|---|---|---|---|
| Ch.4 5.6.1.4, p.247 | Need-to-know, least-privilege access | Server tenant/customer scope; model and tool allowlists; API isolation tests | Bank entitlement source, approval lifecycle, regular access reviews |
| Ch.4 5.6.1.6–7, p.247 | Separated duties and distinct identities | RM/reviewer separation; requester cannot approve; replay/concurrency tests | Bank IdP/MFA, joiner/mover/leaver process and privileged-access controls |
| Ch.4 5.6.1.9, p.247 | Protect authentication material | scrypt password hashes, random expiring sessions, HttpOnly cookie | TLS ingress, passwordless/MFA, enterprise credential custody; local HTTP is demo-only |
| Ch.4 5.11.1.3, p.255 | Protect data confidentiality, integrity and availability | Minimized case fields, synthetic PII redaction, scope isolation | Classification, encryption at rest, retention, validated PII coverage and availability |
| Ch.4 5.12.1.3–4, p.257 | Sufficient event metadata and tamper protection | Actor/time/source/action/outcome, policy version, English/Arabic reason, HMAC/hash chain | Protected SIEM/WORM storage, independent anchors, retention, time trust and operations |
| Ch.4 7.1.1.3/6, p.268 | Threat modelling and adequate security testing | Threat model, 48 fixed cases, negative authorization and browser tests | Independent penetration testing, representative data and release assurance |
| Ch.4 7.1.2.2, p.269 | Defences against AI adversarial attacks | Bounded injection checks plus tool/customer containment even for missed prompts | Stronger detectors, threat updates, red teaming, model-specific adversarial evaluation |
| Ch.4 7.1.2.3, p.269 | Protect training/inference data | No training or customer data ingestion; redaction before local inference | Privacy assessment, approved purpose, governance and bank-classified data protection |
| Ch.4 7.1.2.4–5, p.269 | Auditability and ongoing model evaluation | Decisions trace to policy/content digest; reproducible evaluation | Haris does not explain model reasoning or validate credit/fraud decisions; ongoing drift/reliability monitoring needed |
| Ch.4 6.1.1.2–4, p.265 | Significant IT third-party approval and due diligence | Dependency and founder limitations disclosed | Bank/vendor assessment and applicable CBK approval before engagement |
| Ch.4 7.1.1.2, p.268 | CBK approval process for regulated entities adopting emerging technology | Explicit deployment gate in regulatory case | Entity submits required risk/adoption information at least one month before go-live |
| Ch.4 7.2.1.2–3, p.270 | Cloud data/residency governance and approval | Prototype makes no cloud inference calls | Separate assessment and applicable approval if a future cloud service interacts with sensitive systems |

This application is an individual cybersecurity initiative for SIAP. It is not an application to operate a financial service or enter the regulatory sandbox. A future bank implementation may require approvals and controls independently of accelerator participation.
