# Five ideas and the decision

14 September 2026. Scores are founder-fit judgements, not market measurements. Scale 1–5, higher is better; regulatory burden uses 5 for lower burden. Equal weights avoid a manufactured preference. A clear win requires at least 4/50 more than Haris and no fatal eligibility or buildability issue.

| Idea and named user | Kuwait pain | User clarity | Evidence | Novelty | SIAP fit | Solo build | Measurable value | Low regulatory burden | Defensibility | Credibility | Total |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Haris: one-customer AI case gateway for RM + compliance reviewer | 4 | 5 | 4 | 2 | 5 | 4 | 5 | 5 | 3 | 5 | 42 |
| Dalil: CORF evidence freshness/diff checker for bank control owner | 4 | 5 | 5 | 2 | 5 | 5 | 4 | 5 | 2 | 4 | 41 |
| Rased: dependency outage rehearsal for operational resilience analyst | 4 | 4 | 5 | 3 | 5 | 3 | 4 | 5 | 3 | 4 | 40 |
| Aman: bilingual phishing-report triage for bank SOC analyst | 4 | 5 | 4 | 2 | 5 | 4 | 4 | 5 | 2 | 5 | 40 |
| Sanad: cryptographic asset inventory for bank infrastructure engineer | 4 | 4 | 4 | 3 | 5 | 3 | 4 | 5 | 4 | 4 | 40 |

Dalil checks expiry and evidence relationships, not a generic chatbot. Rased simulates one service outage, not a bank-wide digital twin. Aman prioritizes synthetic reports without asserting reliable fraud adjudication. Sanad inventories a local sample estate without touching bank networks. CORF provides strong need-context for all five, but none has customer validation. Dalil wins ease of build and evidence clarity but loses differentiation. Haris has the most visible causal demonstration of authorization, redaction and human control tied to the applicant's software/security profile. No alternative clearly wins; retain Haris with much narrower scope.

## Strongest case against Haris

A bank can assemble LiteLLM, Presidio, NeMo and its existing IAM/SIEM. A solo founder cannot outperform their detectors, enterprise availability or integrations. An Arabic UI is easy to copy. Keyword injection filters are bypassable and a synthetic demonstration says little about production traffic. “Sovereign” is a deployment property, not a moat or assurance of compliance. A gateway adds a new privileged failure point and procurement burden. No bank has confirmed willingness to buy it.

## Scope decision and remedy

Build one workflow: an RM drafts a minimized customer case; compliance independently approves a fixed internal case-record action. Server-derived tenant identity, assigned-customer scope, allowlisted model/tool and content digest bind every action. The model cannot choose execution authority. Prove the boundary even when detection misses an attack. Provide real local-model integration plus an explicitly labelled deterministic regression adapter, using synthetic data only. No external email, transfers, credit decisions, AML decisions or automated customer contact.

Haris's testable proposition is a locally runnable reference implementation and bilingual decision evidence for this workflow. Future differentiation would come from validated bank adapters and permission/evidence conventions, not invented proprietary detection. Replace custom detection with established components if validation supports it.

## First milestone hostile review

Score before build: fit 18/20, evidence 10/20, differentiation 7/15, functional proof 0/20, security/honesty 11/15, presentation 1/10 = 47/100.

Three rejection reasons: (1) commodity gateway without demand evidence; (2) scope too large for one founder; (3) simulated claims could overstate security. Fixes adopted: explicit competitor overlap and interview plan, one bounded case action, measured controls with limitations and reproducible tests. Demand proof remains a future external validation requirement, not an invented milestone.
