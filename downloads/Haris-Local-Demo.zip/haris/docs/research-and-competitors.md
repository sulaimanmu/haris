# Workflow, alternatives and validation

## Evidence versus hypothesis

**Facts:** NBK reports enterprise AI productivity adoption with Microsoft in its 2025 report. Boubyan reports an AI assistant with Kuwaiti dialect. CORF specifically addresses AI adversarial attacks, inference-data protection and auditability. These are evidence of local relevance, not a reported failure at either bank. Links and source limitations are in `sources.md`.

**Workflow hypothesis:** a relationship manager prepares an annual customer-review case, using notes that may contain identifiers and untrusted material. A compliance reviewer checks the draft before it is recorded internally. The bank's AI platform/security lead would own the enforcement integration; compliance and internal audit would consume decision evidence. These are named roles, not people interviewed.

**Failure mechanism:** pasted notes may redirect an AI model, ask it to retrieve another customer, or solicit an unauthorized tool action. A broad retrieval account or tool credential could turn model error into data disclosure or an action. A reviewer may see only the final prose, without the authority, policy version or content that was approved. Haris tests whether a narrow API boundary prevents those consequences and produces reviewable evidence.

## Proposed workflow, step by step

1. RM signs in and selects an assigned synthetic customer. The server determines the tenant and assignment.
2. RM chooses a draft or internal filing request. User text and source notes are treated as untrusted.
3. The gateway checks customer/model/tool permissions before releasing any context. Known identifiers are redacted. It retrieves only minimized fields for the chosen customer.
4. The fixed local model generates a draft with no tool authority. The output is inspected and returned as plain text.
5. A filing request stores an immutable draft and digest in a pending queue. It does not create a case yet.
6. An independent reviewer approves or rejects that precise content. The backend rechecks authorization, digest, expiry and policy, and commits the case with its decision event atomically.
7. The reviewer exports tenant-specific English/Arabic reason evidence and retains its final hash independently.

## Competitor matrix

Capability descriptions come from linked first-party documentation checked on 14 September 2026. “Gap” means integration work for this proposed workflow, not a claim that a vendor cannot support it. No comparative benchmark or pricing study was conducted.

| Alternative | Established capability | What remains for this workflow | Honest implication for Haris |
|---|---|---|---|
| [Microsoft layered AI defence](https://learn.microsoft.com/en-us/security/zero-trust/sfi/defend-indirect-prompt-injection) | Prompt shields, information-flow isolation, tool-chain analysis and human oversight guidance | Bank-specific case entitlement, content-bound review and evidence integration | A serious incumbent path. Haris needs to show workflow value beyond detectors. |
| [NVIDIA NeMo Guardrails](https://docs.nvidia.com/nemo/guardrails/resources/runtime-security-faq) | Programmable runtime rails, privacy controls, execution and timing evidence | Deployment configuration and bank-specific identity/action workflow | Major overlap. Could replace Haris's elementary detector; no detection-superiority claim. |
| [Presidio](https://microsoft.github.io/presidio/) | Extensible identification and anonymization of PII, local deployment | It is a PII component, so it must be combined with authorization, approval and case actions | Better long-term redaction building block. Haris's fixtures are much narrower. |
| [LiteLLM](https://docs.litellm.ai/docs/proxy/guardrails/quick_start) | Gateway guardrail integrations plus [RBAC](https://docs.litellm.ai/docs/proxy/access_control) | Customer assignments, exact draft review, case execution and bilingual control evidence | Gateway/RBAC are already available. Haris's opportunity is a validated workflow package. |
| Bank's existing IAM + DLP + SIEM + internal engineering | Familiar security systems can be composed around AI | Team must connect model context, action approval and customer scope | Potentially the best option. Haris must outperform an internal reference implementation on integration/review effort. |
| Manual copying and approval | Human judgement and low implementation cost | Repeated minimization and fragmented evidence; actual effort unmeasured | Could be adequate at low volume. No invented savings or universal claim of failure. |

## Why a buyer might decline

The workflow may not exist at meaningful volume. Existing controls may already meet the need. Procurement might prefer an incumbent. A founder could underestimate integration and assurance cost. If a short prototype trial cannot show less review/reconstruction effort without weakening controls, stop or pivot to the smaller evidence-checking idea.

## Future validation plan and decision gates

Recruit, with permission, 3 RMs, 2 compliance reviewers and 2 AI/security platform owners at Kuwaiti banks. These are recruitment targets, not completed interviews. Use synthetic case cards and avoid customer data. Ask participants to show the current approval and evidence process rather than agree with a product pitch.

Questions: What exact task last required an AI-related security exception? What is copied, approved and recorded? Who can access another customer's records? How is approved content bound to execution? Which existing product handles it? What did the last evidence reconstruction require? Who owns budget and procurement? What would prevent even a synthetic trial?

Measure per participant: task-completion time, redaction corrections, unauthorized-access attempts, reviewer decisions, and ability to reconstruct a decision. Compare an approved baseline workflow against Haris using the same synthetic tasks, counterbalanced order. Do not convert lab time directly into bank-wide savings. A proposed continuation gate is no observed unauthorized action/leak, all required decision events present, and a reviewer-confirmed reduction in evidence reconstruction effort. Set numeric commercial targets only after learning the baseline.

No messages or invitations have been sent on the applicant's behalf.
