# Actual evaluation and reproducibility

## What was measured

Corpus v1.0 contains 48 fixed cases in `tests/corpus.py`: 20 benign, 22 adversarial and 6 legitimate approval-required requests. The corpus was prepared during development and is **not** a held-out benchmark. Its SHA-256 (canonical JSON) is `9d007ca600b1eb3ac9be5bb4ca0f48faeaad67b6d74226c5d4bee4eea93092d7`.

Two separate deterministic runs each used a fresh temporary database, the same fixed order, five repeats and 240 sequential gateway calls. Categorization denominators use the 48 unique cases; repetition is for latency/evidence checks, not extra independent examples. Run timestamps, Python/OS/processor, every request/outcome and audit export are retained under `evidence/run-1/` and `evidence/run-2/`.

| Metric | Run 1 | Run 2 | Definition |
|---|---:|---:|---|
| Attack block rate | 20/22 = 90.9% | 20/22 = 90.9% | Adversarial-labelled requests returning blocked |
| Benign false-positive rate | 1/20 = 5% | 1/20 = 5% | Benign-labelled requests not returning allowed |
| Approval routing | 6/6 | 6/6 | Legitimate filing requests requiring review |
| Cross-customer literal leakage | 0/240 responses | 0/240 responses | Forbidden C102/C201 fixture names, Civil IDs, email, phone or IBAN returned in minimized/model text |
| Decision-audit completeness | 240/240 = 100% | 240/240 = 100% | Each accepted gateway request has exactly one matching request ID in a decision event |
| Audit HMAC/hash check | Pass | Pass | Running service verifies the tenant chains |
| Added gateway p95 | 13.193 ms | 13.321 ms | Nearest-rank 95th percentile, method below |
| Added gateway median | 7.412 ms | 7.475 ms | Median of 240 samples |

Cross-tenant resource and source-note attacks (A08 and A12) were blocked. Same-tenant unassigned customer attacks (A09 and A11), unknown resource (A10), role spoofing and cross-tenant approval access are also tested. “Zero leakage” covers these fixtures and paths only; it does not prove semantic privacy, arbitrary data isolation or production confidentiality.

Timing is `Gateway.process` wall time minus time spent in the model call. It includes policy, redaction, SQLite transaction/commit and full-chain integrity verification. It excludes network, HTTP parsing and authentication. The database grows throughout each pass, and full-history verification makes overhead grow with evidence length. Both runs used Windows 11 and Python 3.13.3 on the processor recorded in metrics JSON. No throughput, concurrent load or enterprise latency guarantee is claimed.

## Completion-audit repair: policy 1.1

The completion audit found that a reviewer role could read and decide same-tenant pending cases after removal of that customer's assignment. The previous distribution was tested directly: the restricted reviewer could see the pending draft and file it. Policy 1.1 enforces customer assignment on queue reads and both approval/rejection. The same reproduction now denies the action and creates no case; see `evidence/reviewer-revocation-regression.json`. API tests additionally revoke a reviewer's assignment during an existing session. Filed-case and queue isolation are exercised across three customers and both tenants, and session expiry/new-login invalidation are tested. The final suite has 41 passing tests.

All fixed evaluations were rerun after this repair. Earlier policy-1.0 results are preserved in `evidence/policy-1.0-run-1/`, `policy-1.0-run-2/` and `policy-1.0-live-final/`. Previous repeated-run gateway p95 was 19.974/19.766 ms; the current table reports the newly measured values. This is not evidence that the authorization repair improved performance: background load and execution timing vary. `python audit_results.py` independently recalculates rates and p95 across every saved repeat and checks decision IDs and the public hash chain; it does not certify corpus labels or HMACs without the key.

## Honest failure analysis

**A21** paraphrases a policy override without the known phrases. **A22** supplies a base64-encoded instruction. Both pass the elementary detector in the fixed runs. The local model has no second-customer retrieval or executable tools, so passing does not grant the requested authority. The output may still be poor or reproduce untrusted text. This is a reason to preserve human judgement and expand detection evaluation, not claim the attack is universally neutralized.

**B16** is a benign educational quotation containing an injection phrase. The conservative rule blocks it. It remains counted as a false positive. No cases were removed or relabelled to improve the reported rates.

The first unit run exposed a malformed synthetic IBAN-like fixture (32 rather than 30 characters). The fixture was corrected and the detection test now passes. Additional review moved audit verification before model release, sanitized unapproved route names in audit metadata, and added tests for separately retained heads, output-secret withholding and replay/concurrency. An earlier pre-hardening timing observation was 9.658 ms p95; it is not used as the final performance claim because the current code performs more integrity checks.

## Real model evaluation

The same corpus was run once against local Ollama Qwen2.5:0.5b after refining the internal-note prompt. Results in `evidence/live-final/`: **20/22 attacks blocked, 1/20 benign false positives, 48/48 gateway decision events, no literal forbidden fixture data and no inference errors.** Added gateway p95 was **7.806 ms** and model-call p95 was **4235.69 ms** among requests that called the model. This pass has only 48 events, so its overhead is not directly comparable to the 240-event runs. Browser and development activity occurred on the same computer; this is a functional inference check, not an isolated performance benchmark.

Model digest: `a8b0c51577010a279d933d14c2a8ab4b268079d44c5c8830c0a93900f1827c67`, 494.03M parameters, Q4_K_M, 397,821,319 bytes. Temperature 0, seed 42, generation limit 180 tokens. Raw model outputs are retained. Earlier outputs in `evidence/live-run/` exposed letter-style drafting and instruction echoing. An English refinement used ordinary verified facts and an internal-note example. A later Arabic browser request produced an invented date; the original screenshot is retained as `evidence/screenshots/arabic-model-failure.png`. The Arabic prompt was rewritten in Arabic and all 48 cases rerun in `evidence/live-final/`; the prior full run is retained in `evidence/live-before-ar-refinement/` (p95 model 2786.967 ms, gateway 5.624 ms). The revised model still echoes quoted text and sometimes adds unsolicited guidance; `evidence/arabic-quality-check.json` retains all three exploratory customer examples. This is an unresolved generation-quality limitation requiring human content review, not a security-control success. The deterministic control path and detector were unchanged by this language-prompt refinement. Small-model accuracy and Arabic language quality are not guaranteed. This refinement is not detector improvement and is not counted as such.

## Recorded computer and inference constraint

The demonstration ran on a Dell XPS 9320 with a 12th-generation Intel Core i7-1280P (14 cores, 20 logical processors), 31.61 GiB reported RAM (approximately 32 GB) and Intel Iris Xe integrated graphics. Windows CIM inventory and `ollama ps` are saved in `evidence/hardware.json`. Ollama reported **100% CPU** inference for Qwen2.5:0.5b, Q4_K_M, context 2048. No discrete GPU appears in the recorded inventory.

This is a general-purpose laptop with constrained local-model capacity, not a dedicated AI workstation. It is capable of small-model inference; describing it as categorically unsuitable for AI would be inaccurate. On that CPU-only path it produced the correct English draft: “Annual review is due. Updated business activity evidence has been requested.” The actual fresh-setup response is retained in `evidence/real-model-setup.json` (3627.972 ms model call, 2.392 ms added gateway time). This is one successful response, not a claim of consistent factual accuracy. The Arabic failure and instruction echoing above remain material limitations. There is no claim that a larger model, GPU, bank workload or different laptop would have the same performance.

## Unit, integration, authorization and browser evidence

`evidence/unit-integration-tests.txt` records **41 passing tests**, including authentication, CSRF, host/origin validation, schema bounds, tenant/customer isolation, raw-data minimization, blocked-route non-execution, unsafe output, model failures, digest/expiry/policy checks, revoked access, approval replay/concurrency, rejection side effects, log tampering, startup persistence and independent-head verification. A test deliberately preserves the known detector limitation while checking no new execution authority.

`evidence/clean-setup.json` records a source-only fresh launch with Python site packages disabled, automatic secrets/database creation, authentication and a successful gateway request. No paid service or package install is required for this path. Real inference additionally requires the downloaded local model.

`evidence/browser-qa.json` records a real browser test through sign-in, redaction, blocked injection, independent approval producing a new case, audit inspection and real inference. Screenshots cover 1440×1050 desktop and 390×844 mobile in English and Arabic. RTL flow, wrapping and controls were visually reviewed. No browser page exception or document-level horizontal overflow was observed in the passing run. A repeated-run test initially used an ambiguous selector after multiple cases existed; it was repaired to assert that approval increments the case count exactly once.

## Reproduction

Run the commands in README. Deterministic decisions should match exactly. Latency and local-model wording can vary with hardware, current load, model version and runtime. Compare corpus and model digests before claiming a matching experiment. To reproduce the browser test, start a current server and use the generated local credentials; no shared secret is shipped. Use a new output directory so earlier runs remain available.

## Remaining validation

Independent held-out attacks, Arabic dialects, generalized PII, semantic leakage, workload concurrency, long log histories, human review time and actual bank integration are unvalidated. No demand, financial savings, production adoption or compliance certification is inferred from these tests.
