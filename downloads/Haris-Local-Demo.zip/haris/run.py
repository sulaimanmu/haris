"""One-command local setup: Python standard library only, no package downloads."""
import argparse
import json
import shutil
import subprocess
import time
import urllib.request
from pathlib import Path
from server import make_server

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Haris synthetic-data gateway")
    parser.add_argument("--port", type=int, default=8765)
    parser.add_argument("--data-dir", default=str(Path(__file__).resolve().parent / ".runtime"))
    parser.add_argument("--credentials", action="store_true", help="Print local generated demo passwords")
    parser.add_argument("--prepare-model", action="store_true", help="Start installed Ollama if needed and fetch the fixed local model once")
    args = parser.parse_args()
    model_process = None
    if args.prepare_model:
        def tags():
            with urllib.request.urlopen('http://127.0.0.1:11434/api/tags', timeout=3) as response:
                return json.load(response)
        try:
            models = tags()
        except Exception:
            executable = shutil.which('ollama')
            if not executable:
                parser.error('Install Ollama first, then rerun this one-command setup. No paid account is needed.')
            model_process = subprocess.Popen([executable, 'serve'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            for _ in range(30):
                try:
                    models = tags()
                    break
                except Exception:
                    time.sleep(1)
            else:
                model_process.terminate()
                parser.error('Local Ollama did not become ready. Check the Ollama installation.')
        if not any(m['name'] == 'qwen2.5:0.5b' for m in models['models']):
            print('Downloading the fixed local Qwen model once (about 398 MB).', flush=True)
            request = urllib.request.Request('http://127.0.0.1:11434/api/pull', b'{"model":"qwen2.5:0.5b","stream":false}', {'Content-Type':'application/json'})
            with urllib.request.urlopen(request, timeout=600) as response:
                downloaded = json.load(response)
            if downloaded.get('status') != 'success':
                parser.error('Model download failed. No inference availability is claimed.')
        print('Local Qwen model ready. Select the local Qwen route in the UI.', flush=True)
    server = make_server(args.data_dir, args.port)
    print(f"Haris ready: http://127.0.0.1:{server.server_port}", flush=True)
    print(f"Synthetic data only. Generated credentials: {Path(args.data_dir).resolve() / 'demo-credentials.json'}", flush=True)
    if args.credentials:
        print(Path(args.data_dir, "demo-credentials.json").read_text(), flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        if model_process:
            model_process.terminate()
