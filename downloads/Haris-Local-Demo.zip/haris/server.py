"""Loopback HTTP API. Production deployment requires bank ingress/IdP hardening."""
import hmac
import json
import re
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from core import Gateway, Denied, CUSTOMERS, POLICY_VERSION, REASONS

BASE = Path(__file__).resolve().parent

def validate(body, schema):
    if not isinstance(body, dict) or set(body) - set(schema):
        raise Denied(400)
    for key, (typ, limit, required) in schema.items():
        if key not in body:
            if required:
                raise Denied(400)
            continue
        if type(body[key]) is not typ or (typ is str and (len(body[key]) > limit or (required and not body[key].strip()))):
            raise Denied(400)
    return body

GATEWAY_SCHEMA = {k: (str, limit, required) for k, limit, required in [
    ("customer_id", 8, True), ("prompt", 4000, True), ("source_note", 4000, False),
    ("tool", 32, True), ("model", 60, True), ("language", 2, True)]}

def make_server(directory, port=8765, model_fn=None):
    gateway = Gateway(directory, model_fn)

    class Handler(BaseHTTPRequestHandler):
        server_version = "Haris"
        sys_version = ""

        def log_message(self, *args):
            pass  # Payloads and tokens must never reach access logs.

        def reply(self, status, body, content_type="application/json; charset=utf-8", cookie=None):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode()
            self.send_response(status)
            for key, value in {"Content-Type": content_type, "Content-Length": str(len(data)), "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY", "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'", "Permissions-Policy": "camera=(), microphone=(), geolocation=()"}.items():
                self.send_header(key, value)
            if cookie:
                self.send_header("Set-Cookie", cookie)
            self.end_headers()
            self.wfile.write(data)

        def token(self):
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get("Cookie", ""))
                return cookie["haris_session"].value if "haris_session" in cookie else ""
            except Exception:
                return ""

        def dispatch(self, post=False):
            self.connection.settimeout(100)
            try:
                host = self.headers.get("Host", "")
                permitted = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}"}
                if host not in permitted:
                    raise Denied(400)
                path = urlsplit(self.path).path
                if urlsplit(self.path).query:
                    raise Denied(400)
                if not post and path in ("/", "/app.js", "/style.css"):
                    name = "index.html" if path == "/" else path[1:]
                    ctype = {"index.html": "text/html; charset=utf-8", "app.js": "text/javascript; charset=utf-8", "style.css": "text/css; charset=utf-8"}[name]
                    return self.reply(200, (BASE / "static" / name).read_bytes(), ctype)
                if not post and path == "/api/health":
                    return self.reply(200, {"status": "ok", "synthetic_only": True, "policy": POLICY_VERSION})
                if post:
                    if self.headers.get("Transfer-Encoding") or self.headers.get("Content-Type", "").split(";")[0] != "application/json":
                        raise Denied(415)
                    try:
                        length = int(self.headers.get("Content-Length", "0"))
                    except ValueError:
                        raise Denied(400)
                    if length < 2 or length > 20000:
                        raise Denied(413)
                    origin = self.headers.get("Origin")
                    if origin and origin not in {"http://" + h for h in permitted}:
                        raise Denied(403)
                    body = json.loads(self.rfile.read(length))
                    if path == "/api/login":
                        validate(body, {"username": (str, 40, True), "password": (str, 128, True)})
                        token, user = gateway.login(body["username"], body["password"], self.client_address[0])
                        return self.reply(200, {"user": public_user(user)}, cookie=f"haris_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800")
                user = gateway.session(self.token())
                if post and not hmac.compare_digest(self.headers.get("X-CSRF-Token", ""), user["csrf"]):
                    raise Denied(403)
                if not post and path == "/api/me":
                    return self.reply(200, {"user": public_user(user)})
                if not post and path == "/api/customers":
                    return self.reply(200, {"customers": [{"id": k, "label": c["label"], "label_ar": c["label_ar"], "segment": c["segment"], "segment_ar": c["segment_ar"], "note": c["note"], "note_ar": c["note_ar"]} for k, c in CUSTOMERS.items() if k in user["customers"] and c["tenant"] == user["tenant"]]})
                if not post and path == "/api/approvals":
                    return self.reply(200, {"approvals": gateway.queue(user)})
                if not post and path == "/api/audit":
                    if user["role"] != "reviewer":
                        raise Denied()
                    return self.reply(200, gateway.evidence(user))
                if not post and path == "/api/cases":
                    with gateway.lock:
                        rows = gateway.db.execute("SELECT * FROM cases WHERE tenant=?", (user["tenant"],)).fetchall()
                    return self.reply(200, {"cases": [dict(r) for r in rows if r["customer"] in user["customers"]]})
                if post and path == "/api/gateway":
                    validate(body, GATEWAY_SCHEMA)
                    if body["language"] not in ("en", "ar") or not re.fullmatch(r"C\d{3}", body["customer_id"]):
                        raise Denied(400)
                    return self.reply(200, gateway.process(user, body, self.client_address[0]))
                if post and path == "/api/decision":
                    validate(body, {"approval_id": (str, 24, True), "approve": (bool, 0, True), "digest": (str, 64, True)})
                    return self.reply(200, gateway.decide(user, body["approval_id"], body["approve"], body["digest"]))
                if post and path == "/api/logout":
                    validate(body, {})
                    with gateway.lock:
                        gateway.sessions.pop(self.token(), None)
                        gateway.event(user["tenant"], user["id"], "logout", "success")
                        gateway.db.commit()
                    return self.reply(200, {"status": "ok"}, cookie="haris_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
                raise Denied(404)
            except Denied as error:
                # Record denied API access without retaining request bodies or attacker text.
                try:
                    identity = gateway.session(self.token())
                except Denied:
                    identity = {"tenant": "system", "id": "unknown"}
                with gateway.lock:
                    if gateway.verify_all():
                        gateway.event(identity["tenant"], identity["id"], "api_access", "denied", "authorization", source=self.client_address[0], http_status=error.status)
                        gateway.db.commit()
                self.reply(error.status, {"error": error.reason, "message": "Request could not be authorized or validated.", "message_ar": "تعذر التحقق من الطلب أو التصريح به."})
            except (ValueError, UnicodeError):
                self.reply(400, {"error": "invalid_json"})
            except Exception:
                self.reply(503, {"error": "unavailable", "message": "Service unavailable. No success is confirmed."})

        def do_GET(self):
            self.dispatch()

        def do_POST(self):
            self.dispatch(True)

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    server.daemon_threads = True
    server.gateway = gateway
    return server

def public_user(user):
    return {k: user[k] for k in ("id", "name", "tenant", "role", "customers", "csrf", "expires")}
